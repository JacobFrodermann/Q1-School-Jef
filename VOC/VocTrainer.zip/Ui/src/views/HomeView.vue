<script setup lang="ts">
import TheWelcome from '@/components/Home.vue'
</script>

<template>
  <main>
    <TheWelcome />
  </main>
</template>
