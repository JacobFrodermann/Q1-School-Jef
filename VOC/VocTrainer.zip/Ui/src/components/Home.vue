<script lang="ts">
import Lernset from "./Lernset.vue"
export default {
  components: {
    Lernset
  },
}
</script>

<template>
  <h1>Lernsets:</h1>
  <Lernset Name="Test1" Index="10"></Lernset>
</template>
